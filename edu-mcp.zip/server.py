"""Edu School (Omon School) MCP connector.
Env: EDU_LOGIN, EDU_PASSWORD, MCP_KEY (URL ichidagi maxfiy qism), PORT (Render beradi).
Connector URL: https://<servis>.onrender.com/<MCP_KEY>/mcp
"""
import os, sys, time, datetime, threading, requests
from mcp.server.fastmcp import FastMCP
from mcp.server.transport_security import TransportSecuritySettings
from starlette.responses import PlainTextResponse

API = os.environ.get("EDU_API", "https://backend.eduschool.uz/moderator-api/")
BRANCHES = {"Urganch": "68417f7edbbdfc73ada6ef01", "Gurlan": "684d1fc04921a1211f725ec4", "Shovot": "6a26bf9e3ae51e76c16a8e5d"}
KEY = os.environ.get("MCP_KEY", "")
if len(KEY) < 16:
    sys.exit("MCP_KEY kamida 16 belgi bo'lishi kerak")

_lock = threading.Lock()
_sess = {"token": None, "year": None, "at": 0}

def _login():
    r = requests.post(API + "sign-in", json={"login": os.environ["EDU_LOGIN"], "password": os.environ["EDU_PASSWORD"]},
                      headers={"Organization": "test", "language": "uz"}, timeout=60)
    if r.status_code not in (200, 201):
        raise RuntimeError(f"Edu School login rad etildi (HTTP {r.status_code})")
    d = r.json().get("data") or r.json()
    users = [v for v in (d.values() if isinstance(d, dict) else []) if isinstance(v, dict) and v.get("token")]
    if not users:
        raise RuntimeError("Login javobida token yo'q (OTP yoqilgan bo'lishi mumkin)")
    cur = next((u for u in users if (u.get("academicYear") or {}).get("isCurrent")), users[-1])
    _sess.update(token=cur["token"], year=cur["academicYearId"], at=time.time())

def _get(path, branch_id):
    for attempt in (1, 2):
        with _lock:
            if not _sess["token"] or time.time() - _sess["at"] > 6 * 3600:
                _login()
            h = {"Authorization": "Bearer " + _sess["token"], "Branch": branch_id, "Organization": "test",
                 "academicYearId": _sess["year"], "language": "uz"}
        r = requests.get(API + path, headers=h, timeout=60)
        if r.status_code == 401 and attempt == 1:
            _sess["token"] = None; continue
        if r.status_code != 200:
            raise RuntimeError(f"Edu School {path}: HTTP {r.status_code}")
        return r.json()["data"]

mcp = FastMCP("edu-school", instructions="Omon School (Edu School) filiallari bo'yicha sinflar va o'quvchilar soni.",
              host="0.0.0.0", port=int(os.environ.get("PORT", 8000)), streamable_http_path=f"/{KEY}/mcp",
              stateless_http=True, json_response=True,
              transport_security=TransportSecuritySettings(enable_dns_rebinding_protection=False))

@mcp.tool()
def edu_class_counts() -> dict:
    """Uchala filial (Urganch, Gurlan, Shovot) uchun har sinfdagi faol o'quvchilar sonini qaytaradi.
    Natija: {captured_utc, branches: {Filial: [[sinf_nomi, o'quvchilar_soni], ...]}}. Faqat sonlar, shaxsiy ma'lumot yo'q."""
    out = {"captured_utc": datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "branches": {}}
    for name, bid in BRANCHES.items():
        rows = _get("class/pagin?page=1&limit=200", bid)["data"]
        out["branches"][name] = [[c.get("classLabel") or f"{c.get('grade')}-{c.get('letter')}", c.get("studentsCount", 0)] for c in rows]
    return out

@mcp.tool()
def edu_branch_totals() -> dict:
    """Har filial bo'yicha jami faol o'quvchilar soni va sinflar soni."""
    d = edu_class_counts()
    return {"captured_utc": d["captured_utc"],
            "branches": {n: {"students": sum(c for _, c in rows), "classes": len(rows)} for n, rows in d["branches"].items()}}

@mcp.custom_route("/healthz", methods=["GET"])
async def health(_):
    return PlainTextResponse("ok")

if __name__ == "__main__":
    mcp.run(transport="streamable-http")
