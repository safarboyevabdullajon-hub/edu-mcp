# edu-mcp — Edu School MCP connector

Omon School (Edu School) filiallari bo'yicha sinflar va o'quvchilar sonini Claude'ga beruvchi MCP server. Render'da ishlaydi.

Render env: `EDU_LOGIN`, `EDU_PASSWORD`, `MCP_KEY` (kamida 16 belgili tasodifiy matn).
Build: `pip install -r requirements.txt` · Start: `python server.py`
Claude connector URL: `https://<servis>.onrender.com/<MCP_KEY>/mcp`

Tool'lar: `edu_class_counts`, `edu_branch_totals`.
