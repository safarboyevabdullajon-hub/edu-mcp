# OMON o'quvchilar soni

Har kuni ~09:00 (Toshkent) GitHub Actions Edu School'dan sinflar bo'yicha o'quvchilar sonini oladi, 4 ta rasm (Urganch, Gurlan, Shovot, Jami) yasaydi va Telegram bot orqali 3 ta akkauntga yuboradi. Tarix `history/history.jsonl` da, rasmlar `reports/<sana>/` da saqlanadi.

Secrets (Settings → Secrets and variables → Actions): `EDU_LOGIN`, `EDU_PASSWORD`, `TG_TOKEN`.

Reja `config.json` da (02.11.2026 hisobotidan). Yangi sinf ochilsa, bot sizga eslatma yuboradi — `config.json` ga qator qo'shing.
