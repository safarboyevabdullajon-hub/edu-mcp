# usage: python3 -I build.py <config.json> <raw_snapshot.json> <history.jsonl> <outdir>
# Makes Urganch/Gurlan/Shovot/Jami PNGs, captions.json, today_record.json (history line; NOT appended here)
import json, sys, re, html, asyncio, datetime, os
from playwright.async_api import async_playwright

cfg = json.load(open(sys.argv[1])); raw = json.load(open(sys.argv[2]))
hist_path = sys.argv[3]; out = sys.argv[4]; os.makedirs(out, exist_ok=True)
norm = lambda s: re.sub(r'\s+', ' ', s.strip().upper())
cap = datetime.datetime.fromisoformat(raw['captured_utc'].replace('Z', '+00:00')) + datetime.timedelta(hours=5)
today = cap.date().isoformat(); DATE = cap.strftime('%d.%m.%Y')
hist = [json.loads(l) for l in open(hist_path) if l.strip()]
prevs = [h for h in hist if h['date'] < today]; prev = prevs[-1] if prevs else None
PD = datetime.date.fromisoformat(prev['date']).strftime('%d.%m') if prev else None
gap = (cap.date() - datetime.date.fromisoformat(prev['date'])).days if prev else None

rec = {"date": today, "captured_utc": raw['captured_utc'], "branches": {}, "unmapped": {}}
B = {}
for b in cfg['branches']:
    api = {}
    for lab, c in raw['branches'][b['name']]:
        api[norm(lab)] = api.get(norm(lab), 0) + c
    used = set(); rows = []
    for disp, reja, labs in b['rows']:
        f = 0; found = False
        for l in labs:
            if norm(l) in api:
                f += api[norm(l)]; used.add(norm(l)); found = True
        p = prev['branches'].get(b['name'], {}).get(disp) if prev else None
        rows.append([disp, reja, f, (f - p) if (p is not None and found) else 0, found])
    um = {k: v for k, v in api.items() if k not in used}
    for k, v in um.items():
        rows.append([k + " (yangi)", 0, v, 0, True])
    rec['branches'][b['name']] = {r[0]: r[2] for r in rows if r[4]}
    if um: rec['unmapped'][b['name']] = um
    B[b['name']] = (b['plan'], rows, [r[0] for r in rows if not r[4]])

CSS = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'style.css')).read()
pct = lambda f, r: round(f / r * 100) if r else 0
sp = lambda n: f"{n:,}".replace(',', ' ')
def delta(v):
    if v > 0: return f'<span class="d g">▲ +{v}</span>'
    if v < 0: return f'<span class="d r">▼ −{abs(v)}</span>'
    return '<span class="d">0</span>'
def pill(v):
    cls = "g" if v > 0 else "r" if v < 0 else ""
    return f'<span class="pill {cls}">{"+" if v > 0 else "−" if v < 0 else ""}{abs(v)}</span>'
def chips(L, show_branch=False):
    if not L: return '<div style="color:#999">—</div>'
    return "".join(f'<div class="chip"><span class="nm">{html.escape(n)}{" (" + b + ")" if show_branch else ""}</span>{delta(d)}</div>' for n, d, b in L)
FOOT = (f"Manba: Edu School · Kunlik = oldingi holatga ({PD}) nisbatan o'zgarish" if prev else "Manba: Edu School · oldingi holat yo'q")
ch = lambda L, sb=False: ", ".join(f"{a}{' (' + b + ')' if sb else ''} {'+' if x > 0 else '−'}{abs(x)}" for a, x, b in L)
lbl = "kunlik" if gap == 1 else (f"{gap} kunlik" if gap else "kunlik")

pages = {}; caps = {}; summ = []; ups = []; dns = []
for n, (plan, rows, missing) in B.items():
    f = sum(r[2] for r in rows); d = sum(r[3] for r in rows)
    up = [(r[0], r[3], n) for r in rows if r[3] > 0]; dn = [(r[0], r[3], n) for r in rows if r[3] < 0]
    ups += up; dns += dn; summ.append((n, plan, f, d))
    body = "".join(
        f'<div class="row"><div><div class="nm">{html.escape(a)}</div><div class="bar"><i style="width:{min(100, pct(ff, r))}%"></i></div></div>'
        f'<div class="n">{r or "—"}</div><div class="f">{ff if ok else "—"}</div><div class="n">{str(pct(ff, r)) + "%" if r and ok else "—"}</div>{delta(dd)}</div>'
        for a, r, ff, dd, ok in rows)
    pages[n] = f'''<div class="card"><div class="k">Omon School · {n} filiali</div><div class="t">{DATE} holatiga</div>
<div><span class="big">{f}</span>{pill(d)}</div><div class="sub">Oylik reja {plan} · bajarildi {f / plan * 100:.1f}% · rejagacha {max(plan - f, 0)} ta</div></div>
<div class="two"><div class="card"><div class="h">O'sgan sinflar</div>{chips(up)}</div><div class="card"><div class="h">Kamaygan sinflar</div>{chips(dn)}</div></div>
<div class="card" style="margin-top:16px"><div class="row hd"><div>SINF</div><div class="n">REJA</div><div class="n">FAKT</div><div class="n">BAJARILDI</div><div class="n">KUNLIK</div></div>{body}
<div class="row tot"><div class="nm">Jami</div><div class="n"><b>{plan}</b></div><div class="f">{f}</div><div class="n">{pct(f, plan)}%</div>{delta(d)}</div></div>
<div class="foot">{FOOT}</div>'''
    c = f"{n} · {DATE}: {f}/{plan} ({f / plan * 100:.0f}%), {lbl} {'+' if d > 0 else ''}{d}"
    if up: c += f"\nO'sdi: {ch(up)}"
    if dn: c += f"\nKamaydi: {ch(dn)}"
    if missing: c += f"\nSaytda topilmadi: {', '.join(missing)}"
    caps[n] = c

tp = sum(s[1] for s in summ); tf = sum(s[2] for s in summ); td = sum(s[3] for s in summ)
G = 'grid-template-columns:1fr 64px 60px 84px 62px'
body = "".join(f'<div class="row" style="{G}"><div><div class="nm">{n}</div><div class="bar"><i style="width:{min(100, pct(f, p))}%"></i></div></div>'
               f'<div class="n">{p}</div><div class="f">{f}</div><div class="n">{pct(f, p)}%</div>{delta(d)}</div>' for n, p, f, d in summ)
pages['Jami'] = f'''<div class="card"><div class="k">Omon School · O'quvchilar soni</div><div class="t">{DATE} holatiga</div><div><span class="big">{tf}</span>{pill(td)}</div>
<div class="sub">Oylik reja {sp(tp)} · bajarildi {tf / tp * 100:.1f}% · rejagacha {max(tp - tf, 0)} ta</div></div>
<div class="card"><div class="row hd" style="{G}"><div>FILIAL</div><div class="n">REJA</div><div class="n">FAKT</div><div class="n">BAJARILDI</div><div class="n">KUNLIK</div></div>{body}
<div class="row tot" style="{G}"><div class="nm">Jami</div><div class="n"><b>{sp(tp)}</b></div><div class="f">{tf}</div><div class="n">{pct(tf, tp)}%</div>{delta(td)}</div></div>
<div class="two"><div class="card"><div class="h">O'sgan sinflar</div>{chips(ups, True)}</div><div class="card"><div class="h">Kamaygan sinflar</div>{chips(dns, True)}</div></div>
<div class="foot" style="margin-top:14px">{FOOT}</div>'''
caps['Jami'] = f"Jami · {DATE}: {tf}/{tp} ({tf / tp * 100:.0f}%), rejagacha {max(tp - tf, 0)} ta, {lbl} {'+' if td > 0 else ''}{td}"

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        for n, h in pages.items():
            w = 580 if n == 'Jami' else 520
            pg = await b.new_page(viewport={"width": w + 40, "height": 600}, device_scale_factor=2)
            await pg.set_content(f"<style>{CSS.replace('__W__', str(w) + 'px')}</style>{h}")
            await pg.screenshot(path=f"{out}/{n}.png", full_page=True); await pg.close()
        await b.close()
asyncio.run(main())
json.dump(caps, open(f"{out}/captions.json", "w"), ensure_ascii=False, indent=1)
json.dump(rec, open(f"{out}/today_record.json", "w"), ensure_ascii=False)
print(json.dumps({"date": today, "prev": prev['date'] if prev else None, "totals": summ, "unmapped": rec['unmapped'],
                  "missing": {n: m for n, (_, _, m) in B.items() if m}}, ensure_ascii=False))
