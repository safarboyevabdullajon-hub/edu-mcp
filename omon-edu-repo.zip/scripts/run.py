"""Kunlik: Edu School -> sinflar bo'yicha o'quvchilar soni -> 4 PNG -> Telegram -> history.jsonl
Env: EDU_LOGIN, EDU_PASSWORD, TG_TOKEN, (ixtiyoriy) FORCE=1"""
import os, sys, json, datetime, subprocess, requests
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
API = "https://backend.eduschool.uz/moderator-api/"
CHATS = ["5966398440", "560205110", "7573368074"]
OWNER = "5966398440"
TG = os.environ["TG_TOKEN"]

def tg(method, **kw):
    r = requests.post(f"https://api.telegram.org/bot{TG}/{method}", timeout=60, **kw)
    j = r.json()
    return j.get("ok"), j.get("description", "")

def fail(msg):
    print("XATO:", msg)
    tg("sendMessage", data={"chat_id": OWNER, "text": f"OMON o'quvchilar hisoboti yuborilmadi: {msg}"})
    sys.exit(1)

cfg = json.load(open(f"{ROOT}/config.json"))
hist_path = f"{ROOT}/history/history.jsonl"
now = datetime.datetime.now(datetime.timezone.utc)
today = (now + datetime.timedelta(hours=5)).date().isoformat()
hist = [json.loads(l) for l in open(hist_path) if l.strip()]
if hist and hist[-1]["date"] == today and os.environ.get("FORCE") != "1":
    print("Bugun allaqachon yuborilgan, o'tkazib yuborildi."); sys.exit(0)

H = {"Organization": "test", "language": "uz", "Accept": "application/json"}
try:
    r = requests.post(API + "sign-in", json={"login": os.environ["EDU_LOGIN"], "password": os.environ["EDU_PASSWORD"]}, headers=H, timeout=60)
except Exception as e:
    fail(f"Edu School'ga ulanib bo'lmadi ({type(e).__name__})")
if r.status_code not in (200, 201):
    fail(f"login rad etildi (HTTP {r.status_code}) — login/parolni tekshiring")
d = r.json().get("data") or r.json()
users = [v for v in (d.values() if isinstance(d, dict) else []) if isinstance(v, dict) and v.get("token")]
if not users:
    fail("login javobida token yo'q (ehtimol OTP yoqilgan)")
cur = next((u for u in users if (u.get("academicYear") or {}).get("isCurrent")), users[-1])
H.update({"Authorization": "Bearer " + cur["token"], "academicYearId": cur["academicYearId"]})

raw = {"captured_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "branches": {}}
for b in cfg["branches"]:
    rr = requests.get(API + "class/pagin?page=1&limit=200", headers={**H, "Branch": b["id"]}, timeout=60)
    if rr.status_code != 200:
        fail(f"{b['name']} sinflari olinmadi (HTTP {rr.status_code})")
    rows = rr.json()["data"]["data"]
    if len(rows) < 10:
        fail(f"{b['name']}: faqat {len(rows)} ta sinf qaytdi")
    raw["branches"][b["name"]] = [[c.get("classLabel") or f"{c['grade']}-{c['letter']}", c["studentsCount"]] for c in rows]

out = f"{ROOT}/reports/{today}"
os.makedirs(out, exist_ok=True)
json.dump(raw, open(f"{out}/raw.json", "w"), ensure_ascii=False)
p = subprocess.run([sys.executable, f"{ROOT}/scripts/build.py", f"{ROOT}/config.json", f"{out}/raw.json", hist_path, out], capture_output=True, text=True)
print(p.stdout, p.stderr)
if p.returncode:
    fail("rasm yasashda xato")
info = json.loads(p.stdout.strip().splitlines()[-1])
caps = json.load(open(f"{out}/captions.json"))
warn = []
if info["unmapped"]: warn.append("yangi sinflar: " + "; ".join(f"{k}: {', '.join(v)}" for k, v in info["unmapped"].items()))
if info["missing"]: warn.append("topilmagan sinflar: " + "; ".join(f"{k}: {', '.join(v)}" for k, v in info["missing"].items()))

bad = []
for cid in CHATS:
    for n in ["Urganch", "Gurlan", "Shovot", "Jami"]:
        with open(f"{out}/{n}.png", "rb") as f:
            ok, desc = tg("sendPhoto", data={"chat_id": cid, "caption": caps[n]}, files={"photo": f})
        print(cid, n, "ok" if ok else "ERR " + desc)
        if not ok: bad.append(f"{cid} {n}: {desc}")
if warn:
    tg("sendMessage", data={"chat_id": OWNER, "text": "Eslatma (konfigni yangilash kerak): " + " | ".join(warn)})
if bad:
    tg("sendMessage", data={"chat_id": OWNER, "text": "Ba'zi xabarlar yetmadi: " + "; ".join(bad)})

rec = json.load(open(f"{out}/today_record.json"))
with open(hist_path, "a") as f:
    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
print("Tayyor:", info["totals"])
